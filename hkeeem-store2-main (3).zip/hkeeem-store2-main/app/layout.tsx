import type { Metadata, Viewport } from 'next'
import './globals.css'
import Header from '../components/Header'

export const metadata: Metadata = {
  metadataBase: new URL('https://hakeem.store'),
  title: {
    default: 'متجر حكيم | عطور ومحافظ فاخرة - جدة',
    template: '%s | متجر حكيم',
  },
  description:
    'عطر حكيم الملكي 100مل ومحافظ جلد أصلية - توصيل سريع لكل السعودية والدفع عند الاستلام. تواصل: info@hakeem.store',
  keywords: ['متجر حكيم', 'عطر حكيم', 'عطور جدة', 'hakeem.store', 'hkeeem'],
  authors: [{ name: 'متجر حكيم' }],
  icons: {
    icon: [
      { url: '/hkeeem_192.png', sizes: '192x192', type: 'image/png' },
      { url: '/hkeeem_512.png', sizes: '512x512', type: 'image/png' },
    ],
    apple: [{ url: '/hkeeem_192.png', sizes: '180x180', type: 'image/png' }],
  },
  openGraph: {
    type: 'website',
    locale: 'ar_SA',
    url: 'https://hakeem.store',
    siteName: 'متجر حكيم',
    title: 'متجر حكيم - عطور فاخرة',
    description: 'عطر حكيم الملكي مع محفظة فاخرة - عرض خاص 399 ر.س',
    images: ['/hkeeem_512.png'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'متجر حكيم',
    description: 'عطور ومحافظ فاخرة',
    images: ['/hkeeem_512.png'],
  },
  manifest: '/manifest.json',
}

export const viewport: Viewport = {
  themeColor: '#D4AF37',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-[#0A0A0A] text-white">
        <Header />
        <main>{children}</main>
      </body>
    </html>
  )
}
