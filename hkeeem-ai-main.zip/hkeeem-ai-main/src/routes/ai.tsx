import { createFileRoute } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { useI18n } from "@/lib/i18n";
import { useLiveLocation } from "@/lib/use-location";
import { allBranches, STORES } from "@/lib/mock-data";
import { haversineKm } from "@/lib/geo";
import { useMemo, useState } from "react";
import { Sparkles, Send, Loader2 } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { recommendNearby } from "@/lib/ai-recommend.functions";
import { StoreCard } from "@/components/StoreCard";
import { toast } from "sonner";

export const Route = createFileRoute("/ai")({
  head: () => ({
    meta: [
      { title: "مساعد حكيم الذكي — أفضل توصية قريبة منك" },
      { name: "description", content: "توصية ذكية تجمع بين السعر، الكاش باك، الكوبونات، والمسافة لاختيار الأفضل لك." },
    ],
  }),
  component: AIPage,
});

function AIPage() {
  const { t, lang, fmtDistance } = useI18n();
  const { coords } = useLiveLocation();
  const recommend = useServerFn(recommendNearby);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ bestStoreId: string; reason: string; alternatives: { storeId: string; reason: string }[] } | null>(null);

  const nearby = useMemo(
    () =>
      allBranches()
        .map((it) => ({ ...it, distanceKm: haversineKm(coords, { lat: it.branch.lat, lng: it.branch.lng }) }))
        .sort((a, b) => a.distanceKm - b.distanceKm)
        .slice(0, 15),
    [coords],
  );

  async function ask(query: string) {
    if (!query.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const candidates = nearby.map((it) => ({
        storeId: it.store.id,
        storeName: it.store.name[lang],
        category: it.store.category,
        distanceKm: Math.round(it.distanceKm * 10) / 10,
        cashbackPct: it.store.cashbackPct,
        rating: it.store.rating,
        openNow: it.store.openNow,
        bestOffer: {
          title: it.store.offers[0]?.title[lang] ?? "",
          discountPct: it.store.offers[0]?.discountPct,
          priceFrom: it.store.offers[0]?.priceFrom,
          pickupMinutes: it.store.offers[0]?.pickupMinutes,
        },
      }));
      const res = await recommend({ data: { query, lang, candidates } });
      setResult(res);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  const best = result ? nearby.find((n) => n.store.id === result.bestStoreId) ?? nearby[0] : null;
  const alts = result
    ? result.alternatives
        .map((a) => ({ item: nearby.find((n) => n.store.id === a.storeId), reason: a.reason }))
        .filter((x): x is { item: (typeof nearby)[number]; reason: string } => !!x.item)
    : [];

  const suggestions =
    lang === "ar"
      ? ["أرخص برجر قريب", "أعلى كاش باك في الصيدليات", "قهوة سريعة الاستلام", "خصم على إلكترونيات"]
      : ["Cheapest burger nearby", "Highest pharmacy cashback", "Fastest coffee pickup", "Electronics discount"];

  return (
    <div className="min-h-screen pb-24">
      <AppHeader />
      <div className="mx-auto max-w-md px-4 py-4">
        <div className="hero-gradient relative overflow-hidden rounded-3xl p-5 text-white shadow-[var(--shadow-soft)]">
          <div className="absolute -end-6 -top-6 size-24 rounded-full bg-gold/40 blur-2xl" />
          <div className="relative flex items-center gap-3">
            <div className="grid size-12 place-items-center rounded-2xl bg-gold text-gold-foreground shadow-[var(--shadow-glow)]">
              <Sparkles className="size-6" />
            </div>
            <div>
              <div className="text-lg font-black">{t("ai_title")}</div>
              <div className="text-xs text-white/85">{t("ai_subtitle")}</div>
            </div>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            ask(q);
          }}
          className="mt-4 flex items-center gap-2 rounded-full border border-border bg-card p-1.5 shadow-sm focus-within:ring-2 focus-within:ring-primary/30"
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("ai_ask")}
            className="flex-1 bg-transparent px-3 py-2 text-sm outline-none placeholder:text-muted-foreground"
          />
          <button
            type="submit"
            disabled={loading || !q.trim()}
            className="grid size-9 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground disabled:opacity-50"
          >
            {loading ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
          </button>
        </form>

        <div className="mt-3 flex flex-wrap gap-1.5">
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => {
                setQ(s);
                ask(s);
              }}
              className="rounded-full border border-border bg-card px-3 py-1 text-[11px] font-medium text-foreground/80 hover:bg-muted"
            >
              {s}
            </button>
          ))}
        </div>

        {loading && (
          <div className="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> {t("ai_thinking")}
          </div>
        )}

        {result && best && (
          <div className="mt-6 space-y-4">
            <div className="rounded-3xl border-2 border-gold/50 bg-gradient-to-b from-gold/10 to-transparent p-4 shadow-[var(--shadow-glow)]">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-gold-foreground">
                <Sparkles className="size-3.5 text-gold" />
                {t("ai_best_pick")}
              </div>
              <StoreCard store={best.store} branch={best.branch} distanceKm={best.distanceKm} />
              {result.reason && (
                <div className="mt-3 rounded-2xl bg-card/70 p-3 text-sm text-foreground/90">
                  <div className="text-[11px] font-bold uppercase text-muted-foreground">{t("ai_reason")}</div>
                  <p className="mt-1 leading-relaxed">{result.reason}</p>
                </div>
              )}
            </div>

            {alts.length > 0 && (
              <div>
                <h3 className="mb-2 text-sm font-bold">{t("ai_alternatives")}</h3>
                <div className="space-y-2">
                  {alts.map((a) => (
                    <div key={a.item.branch.id} className="space-y-1">
                      <StoreCard store={a.item.store} branch={a.item.branch} distanceKm={a.item.distanceKm} />
                      {a.reason && (
                        <p className="px-2 text-[11px] leading-relaxed text-muted-foreground">{a.reason}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {!result && !loading && (
          <p className="mt-6 text-center text-xs text-muted-foreground">
            {t("ai_examples")} · {fmtDistance(0)} · {STORES.length}× {t("offers_count")}
          </p>
        )}
      </div>
      <BottomNav />
    </div>
  );
}
