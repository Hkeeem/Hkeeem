import { createFileRoute, Link } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { useI18n } from "@/lib/i18n";
import { useLiveLocation } from "@/lib/use-location";
import { CATEGORY_META, allBranches, type Category } from "@/lib/mock-data";
import { haversineKm } from "@/lib/geo";
import { StoreCard } from "@/components/StoreCard";
import { useMemo } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/nearby/")({
  head: () => ({
    meta: [
      { title: "بالقرب مني — حكيم" },
      { name: "description", content: "تصفح الفئات وأقرب المتاجر والعروض حسب موقعك الحالي." },
    ],
  }),
  component: NearbyIndex,
});

function NearbyIndex() {
  const { t, lang, dir } = useI18n();
  const { coords } = useLiveLocation();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const nearby = useMemo(
    () =>
      allBranches()
        .map((it) => ({ ...it, distanceKm: haversineKm(coords, { lat: it.branch.lat, lng: it.branch.lng }) }))
        .sort((a, b) => a.distanceKm - b.distanceKm),
    [coords],
  );

  return (
    <div className="min-h-screen pb-24">
      <AppHeader />
      <div className="mx-auto max-w-md px-4 py-4">
        <h1 className="text-xl font-black">{t("nearby_deals")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("sort_nearest")}</p>

        <div className="mt-4 grid grid-cols-2 gap-2">
          {(Object.keys(CATEGORY_META) as Category[]).map((c) => (
            <Link
              key={c}
              to="/nearby/$category"
              params={{ category: c }}
              className="group relative overflow-hidden rounded-2xl border border-border/60 bg-card p-4 transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-soft)]"
            >
              <div
                className="absolute -end-4 -top-4 grid size-16 place-items-center rounded-full text-3xl opacity-60"
                style={{ background: `color-mix(in oklch, ${CATEGORY_META[c].color} 18%, white)` }}
              >
                {CATEGORY_META[c].icon}
              </div>
              <div className="relative">
                <div className="text-base font-bold">{CATEGORY_META[c].label[lang]}</div>
                <div className="mt-1 flex items-center gap-1 text-xs text-primary">
                  {t("see_all")} <Arrow className="size-3" />
                </div>
              </div>
            </Link>
          ))}
        </div>

        <h2 className="mt-8 text-base font-extrabold">{t("stores_near_me")}</h2>
        <div className="mt-3 space-y-2">
          {nearby.slice(0, 12).map((it) => (
            <StoreCard key={it.branch.id} store={it.store} branch={it.branch} distanceKm={it.distanceKm} />
          ))}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
