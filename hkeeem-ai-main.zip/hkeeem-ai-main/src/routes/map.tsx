import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useMemo, useState } from "react";
import { BottomNav } from "@/components/BottomNav";
import { AppHeader } from "@/components/AppHeader";
import { useLiveLocation } from "@/lib/use-location";
import { useI18n } from "@/lib/i18n";
import { CATEGORY_META, STORES, type Category, allBranches } from "@/lib/mock-data";
import { haversineKm } from "@/lib/geo";
import { Search, Loader2 } from "lucide-react";
import { StoreCard } from "@/components/StoreCard";

const MapView = lazy(() => import("@/components/MapView").then((m) => ({ default: m.MapView })));

export const Route = createFileRoute("/map")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "الخريطة التفاعلية — حكيم" },
      { name: "description", content: "خريطة تفاعلية لكل المتاجر الشريكة والعروض القريبة منك مع تجميع ذكي للمواقع." },
    ],
  }),
  component: MapPage,
});

function MapPage() {
  const { t, lang } = useI18n();
  const { coords } = useLiveLocation();
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<Category | "all">("all");

  const q = query.trim().toLowerCase();
  const filteredStores = useMemo(() => {
    return STORES.filter((s) => {
      if (cat !== "all" && s.category !== cat) return false;
      if (!q) return true;
      const hay = [s.name.ar, s.name.en, s.city.ar, s.city.en, ...s.branches.flatMap((b) => [b.district.ar, b.district.en])]
        .join(" ")
        .toLowerCase();
      return hay.includes(q);
    });
  }, [cat, q]);

  const filteredIds = filteredStores.map((s) => s.id);

  const results = useMemo(() => {
    const set = new Set(filteredIds);
    return allBranches()
      .filter((it) => set.has(it.store.id))
      .map((it) => ({ ...it, distanceKm: haversineKm(coords, { lat: it.branch.lat, lng: it.branch.lng }) }))
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }, [filteredIds, coords]);

  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <div className="flex h-screen flex-col pb-16">
      <AppHeader />
      <div className="mx-auto flex w-full max-w-md flex-col gap-2 px-4 py-3">
        <label className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2.5 shadow-sm">
          <Search className="size-4 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("search_placeholder")}
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </label>
        <div className="-mx-4 flex gap-1.5 overflow-x-auto px-4 pb-1">
          <FilterChip active={cat === "all"} onClick={() => setCat("all")} label={t("filter_all")} />
          {(Object.keys(CATEGORY_META) as Category[]).map((c) => (
            <FilterChip
              key={c}
              active={cat === c}
              onClick={() => setCat(c)}
              label={`${CATEGORY_META[c].icon} ${CATEGORY_META[c].label[lang]}`}
            />
          ))}
        </div>
      </div>

      <div className="relative mx-auto h-[45vh] w-full max-w-md overflow-hidden rounded-2xl bg-muted">
        {mounted ? (
          <Suspense fallback={<MapFallback />}>
            <MapView userCoords={coords} filterStoreIds={filteredIds} />
          </Suspense>
        ) : (
          <MapFallback />
        )}
      </div>

      <div className="mx-auto mt-3 w-full max-w-md flex-1 overflow-y-auto px-4 pb-6">
        <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground">
          <span>{t("sort_nearest")}</span>
          <span>
            {results.length} {t("offers_count")}
          </span>
        </div>
        <div className="space-y-2">
          {results.slice(0, 20).map((it) => (
            <StoreCard key={it.branch.id} store={it.store} branch={it.branch} distanceKm={it.distanceKm} />
          ))}
          {results.length === 0 && (
            <div className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
              {t("no_results")}
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}

function FilterChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition ${
        active
          ? "border-primary bg-primary text-primary-foreground shadow-[var(--shadow-soft)]"
          : "border-border bg-card text-foreground hover:bg-muted"
      }`}
    >
      {label}
    </button>
  );
}

function MapFallback() {
  return (
    <div className="grid h-full place-items-center text-muted-foreground">
      <Loader2 className="size-6 animate-spin" />
    </div>
  );
}
