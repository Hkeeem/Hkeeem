import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { useI18n } from "@/lib/i18n";
import { useLiveLocation } from "@/lib/use-location";
import { CATEGORY_META, allBranches, type Category } from "@/lib/mock-data";
import { haversineKm } from "@/lib/geo";
import { StoreCard } from "@/components/StoreCard";
import { useMemo } from "react";
import { ChevronRight, ChevronLeft } from "lucide-react";

const CATS: Category[] = ["restaurants", "pharmacies", "supermarkets", "electronics", "fashion", "realestate", "coffee", "beauty"];

export const Route = createFileRoute("/nearby/$category")({
  parseParams: (p) => {
    if (!CATS.includes(p.category as Category)) throw notFound();
    return { category: p.category as Category };
  },
  component: CategoryPage,
});

function CategoryPage() {
  const params = Route.useParams();
  const category = params.category as Category;
  const { t, lang, dir } = useI18n();
  const { coords } = useLiveLocation();
  const meta = CATEGORY_META[category];

  const items = useMemo(
    () =>
      allBranches()
        .filter((it) => it.store.category === category)
        .map((it) => ({ ...it, distanceKm: haversineKm(coords, { lat: it.branch.lat, lng: it.branch.lng }) }))
        .sort((a, b) => a.distanceKm - b.distanceKm),
    [coords, category],
  );

  const Back = dir === "rtl" ? ChevronRight : ChevronLeft;

  return (
    <div className="min-h-screen pb-24">
      <AppHeader />
      <div className="mx-auto max-w-md px-4 py-4">
        <Link to="/nearby" className="mb-3 inline-flex items-center gap-1 text-xs font-semibold text-primary">
          <Back className="size-4" /> {t("nav_nearby")}
        </Link>
        <div className="flex items-center gap-3">
          <div
            className="grid size-14 place-items-center rounded-2xl text-3xl"
            style={{ background: `color-mix(in oklch, ${meta.color} 18%, white)` }}
          >
            {meta.icon}
          </div>
          <div>
            <h1 className="text-xl font-black">{meta.label[lang]}</h1>
            <p className="text-xs text-muted-foreground">
              {items.length} · {t("sort_nearest")}
            </p>
          </div>
        </div>

        <div className="mt-5 space-y-2">
          {items.map((it) => (
            <StoreCard key={it.branch.id} store={it.store} branch={it.branch} distanceKm={it.distanceKm} />
          ))}
          {items.length === 0 && (
            <div className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
              {t("no_results")}
            </div>
          )}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
