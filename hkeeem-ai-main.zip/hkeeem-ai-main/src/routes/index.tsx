import { createFileRoute, Link } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { useI18n } from "@/lib/i18n";
import { useLiveLocation } from "@/lib/use-location";
import { STORES, CATEGORY_META, type Category, allBranches } from "@/lib/mock-data";
import { haversineKm } from "@/lib/geo";
import { StoreCard } from "@/components/StoreCard";
import { trackEvent } from "@/lib/analytics";
import { useMemo } from "react";
import { MapPin, Search, Sparkles, Radio, ArrowLeft, ArrowRight, Zap, Flame, Store as StoreIcon, Building2, ExternalLink } from "lucide-react";

const DEALAPP_URL =
  "https://dealapp.sa/ar/profile/67c08063ca5bafdb59e3d8d4?utm_source=visit_my_profile";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "حكيم — العروض والكاش باك القريبة منك" },
      { name: "description", content: "اكتشف أفضل العروض والخصومات والكاش باك في المتاجر القريبة منك، مع توصيات ذكية من مساعد حكيم." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { t, lang, dir, fmtDistance } = useI18n();
  const { coords, status } = useLiveLocation();

  const sortedNearby = useMemo(() => {
    return allBranches()
      .map((it) => ({ ...it, distanceKm: haversineKm(coords, { lat: it.branch.lat, lng: it.branch.lng }) }))
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }, [coords]);

  const flash = sortedNearby.filter((it) => it.store.offers.some((o) => o.flash)).slice(0, 6);
  const newest = sortedNearby.filter((it) => it.store.offers.some((o) => o.newlyAdded)).slice(0, 6);
  const today = sortedNearby.filter((it) => it.store.offers.some((o) => o.todayOnly)).slice(0, 6);

  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  return (
    <div className="min-h-screen pb-24">
      <AppHeader />

      <div className="mx-auto max-w-md px-4 pt-4">
        {/* Hero */}
        <section className="hero-gradient relative overflow-hidden rounded-3xl p-5 text-white shadow-[var(--shadow-soft)]">
          <div className="absolute -end-8 -top-8 size-32 rounded-full bg-gold/30 blur-2xl" />
          <div className="relative">
            <div className="flex items-center gap-1.5 text-xs font-semibold">
              <Radio className="size-3.5 animate-pulse text-gold" />
              <span>{t("live_updates")}</span>
            </div>
            <h1 className="mt-2 text-2xl font-black leading-tight">
              {t("nearby_deals")}
            </h1>
            <p className="mt-1 text-sm text-white/85">
              {status === "loading" ? t("requesting_location") : status === "denied" ? t("location_denied") : t("app_tagline")}
            </p>

            <Link
              to="/map"
              className="mt-4 flex items-center gap-2 rounded-full bg-white/15 px-4 py-2.5 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/25"
            >
              <Search className="size-4" />
              <span className="flex-1 text-start opacity-90">{t("search_placeholder")}</span>
              <MapPin className="size-4" />
            </Link>

            <Link
              to="/ai"
              className="mt-3 flex items-center justify-between gap-2 rounded-2xl bg-gold px-4 py-3 text-gold-foreground shadow-[var(--shadow-glow)] transition hover:opacity-95"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="size-5" />
                <div>
                  <div className="text-sm font-black">{t("ai_title")}</div>
                  <div className="text-[11px] opacity-80">{t("ai_subtitle")}</div>
                </div>
              </div>
              <Arrow className="size-5" />
            </Link>
          </div>
        </section>

        {/* Categories */}
        <section className="mt-6">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-extrabold">{t("nav_nearby")}</h2>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {(Object.keys(CATEGORY_META) as Category[]).map((c) => (
              <Link
                key={c}
                to="/nearby/$category"
                params={{ category: c }}
                className="flex flex-col items-center gap-1.5 rounded-2xl border border-border/60 bg-card p-2 text-center transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-soft)]"
              >
                <div
                  className="grid size-11 place-items-center rounded-xl text-xl"
                  style={{ background: `color-mix(in oklch, ${CATEGORY_META[c].color} 18%, white)` }}
                >
                  {CATEGORY_META[c].icon}
                </div>
                <span className="text-[11px] font-semibold leading-tight text-foreground">
                  {CATEGORY_META[c].label[lang]}
                </span>
              </Link>
            ))}
          </div>
        </section>

        <SectionCarousel
          icon={<Zap className="size-4 text-primary" />}
          title={t("flash_deals")}
          items={flash}
        />
        <SectionCarousel
          icon={<Flame className="size-4 text-destructive" />}
          title={t("today_discounts")}
          items={today}
        />
        <SectionCarousel
          icon={<Sparkles className="size-4 text-gold" />}
          title={t("new_offers")}
          items={newest}
        />

        <section className="mt-8">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-1.5 text-base font-extrabold">
              <StoreIcon className="size-4" /> {t("stores_near_me")}
            </h2>
            <Link to="/nearby" className="text-xs font-semibold text-primary">
              {t("see_all")}
            </Link>
          </div>
          <div className="space-y-2">
            {sortedNearby.slice(0, 6).map((it) => (
              <StoreCard key={it.branch.id} store={it.store} branch={it.branch} distanceKm={it.distanceKm} />
            ))}
          </div>
        </section>

        {/* Real Estate — Virtual Office */}
        <section className="mt-8">
          <div className="relative overflow-hidden rounded-3xl border border-gold/40 bg-gradient-to-br from-primary via-primary to-[color-mix(in_oklch,var(--color-primary)_75%,black)] p-5 text-white shadow-[var(--shadow-soft)]">
            <div className="absolute -end-10 -top-10 size-40 rounded-full bg-gold/25 blur-2xl" />
            <div className="relative flex items-start gap-3">
              <div className="grid size-12 shrink-0 place-items-center rounded-2xl bg-gold text-gold-foreground shadow-[var(--shadow-glow)]">
                <Building2 className="size-6" />
              </div>
              <div className="flex-1">
                <div className="text-[11px] font-semibold uppercase tracking-wide text-gold">
                  {t("cat_realestate")}
                </div>
                <h2 className="mt-0.5 text-lg font-black leading-tight">{t("realestate_title")}</h2>
                <p className="mt-0.5 text-xs font-semibold text-white/85">{t("realestate_org")}</p>
                <p className="mt-2 text-sm leading-relaxed text-white/90">{t("realestate_desc")}</p>
              </div>
            </div>

            <a
              href={DEALAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={t("realestate_cta")}
              data-analytics-id="realestate_dealapp_cta"
              onClick={(e) =>
                trackEvent("realestate_dealapp_click", {
                  source: "home_virtual_office_card",
                  destination: DEALAPP_URL,
                  utm_source: "visit_my_profile",
                  org: "mohsen_business_services",
                  lang,
                  button: (e.currentTarget as HTMLAnchorElement).getAttribute("aria-label"),
                })
              }
              className="relative mt-4 flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-gold px-5 py-3 text-center text-sm font-black text-gold-foreground shadow-[var(--shadow-glow)] transition active:scale-[0.98] hover:brightness-105"
            >
              <ExternalLink className="size-4 shrink-0" />
              <span className="leading-tight">{t("realestate_cta")}</span>
            </a>
            <p className="relative mt-2 text-center text-[11px] text-white/70">
              {t("realestate_cta_hint")}
            </p>
          </div>
        </section>

        <p className="mt-6 text-center text-[11px] text-muted-foreground">

          {t("you_are_here")}: {fmtDistance(0)} · {STORES.length}× {t("offers_count")}
        </p>
      </div>

      <BottomNav />
    </div>
  );
}

function SectionCarousel({
  title,
  icon,
  items,
}: {
  title: string;
  icon: React.ReactNode;
  items: Array<{ store: (typeof STORES)[number]; branch: (typeof STORES)[number]["branches"][number]; distanceKm: number }>;
}) {
  if (items.length === 0) return null;
  return (
    <section className="mt-6">
      <h2 className="mb-3 flex items-center gap-1.5 text-base font-extrabold">
        {icon} {title}
      </h2>
      <div className="-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-1">
        {items.map((it) => (
          <div key={it.branch.id} className="w-[86%] shrink-0 snap-start">
            <StoreCard store={it.store} branch={it.branch} distanceKm={it.distanceKm} compact />
          </div>
        ))}
      </div>
    </section>
  );
}
