import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import type { Store, Branch } from "@/lib/mock-data";
import { Star, MapPin, Clock, BadgePercent, Zap, Timer, Navigation, Building2 } from "lucide-react";

export function StoreDetails({
  store,
  branch,
  distanceKm,
  open,
  onOpenChange,
}: {
  store: Store;
  branch: Branch;
  distanceKm: number;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const { t, lang, fmtDistance, fmtCurrency } = useI18n();
  const gmaps = `https://www.google.com/maps/dir/?api=1&destination=${branch.lat},${branch.lng}`;
  const amaps = `https://maps.apple.com/?daddr=${branch.lat},${branch.lng}&dirflg=d`;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="max-h-[92vh] overflow-y-auto rounded-t-3xl p-0">
        <div
          className="relative px-5 pt-6 pb-5 text-white"
          style={{
            background: `linear-gradient(135deg, ${store.brandColor} 0%, color-mix(in oklch, ${store.brandColor} 60%, black) 100%)`,
          }}
        >
          <div className="flex items-center gap-3">
            <div className="grid size-16 place-items-center rounded-2xl bg-white/20 text-4xl backdrop-blur">
              {store.logo}
            </div>
            <div>
              <SheetHeader className="p-0">
                <SheetTitle className="text-start text-2xl font-extrabold text-white">
                  {store.name[lang]}
                </SheetTitle>
              </SheetHeader>
              <div className="mt-1 flex items-center gap-2 text-sm text-white/90">
                <Star className="size-3.5 fill-current" />
                {store.rating.toFixed(1)} ({store.reviews.toLocaleString(lang === "ar" ? "ar-SA" : "en-US")})
                <span>·</span>
                <span className={store.openNow ? "text-emerald-200" : "text-red-200"}>
                  {store.openNow ? t("open_now") : t("closed")}
                </span>
              </div>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="gold-chip inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs">
              <BadgePercent className="size-3.5" /> {store.cashbackPct}% {t("cashback")}
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-3 py-1 text-xs font-semibold backdrop-blur">
              <MapPin className="size-3.5" /> {fmtDistance(distanceKm)}
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-3 py-1 text-xs font-semibold backdrop-blur">
              <Clock className="size-3.5" /> {store.hours[lang]}
            </span>
          </div>
        </div>

        <div className="space-y-5 px-5 py-5">
          <div className="grid grid-cols-2 gap-2">
            <Button asChild className="rounded-full bg-primary font-bold">
              <a href={gmaps} target="_blank" rel="noreferrer">
                <Navigation className="me-1 size-4" /> {t("google_maps")}
              </a>
            </Button>
            <Button asChild variant="outline" className="rounded-full border-primary/30 font-bold text-primary">
              <a href={amaps} target="_blank" rel="noreferrer">
                <Navigation className="me-1 size-4" /> {t("apple_maps")}
              </a>
            </Button>
          </div>

          <section>
            <h3 className="mb-2 text-sm font-bold text-foreground">{t("offers")}</h3>
            <div className="space-y-2">
              {store.offers.map((o) => (
                <div key={o.id} className="rounded-2xl border border-border/60 bg-card p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-semibold text-foreground">{o.title[lang]}</div>
                    {o.discountPct && (
                      <span className="rounded-full bg-destructive/10 px-2 py-0.5 text-xs font-bold text-destructive">
                        -{o.discountPct}%
                      </span>
                    )}
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px]">
                    {o.cashbackPct && (
                      <span className="gold-chip inline-flex items-center gap-1 rounded-full px-2 py-0.5">
                        <BadgePercent className="size-3" /> {o.cashbackPct}%
                      </span>
                    )}
                    {o.flash && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 font-semibold text-primary">
                        <Zap className="size-3" /> Flash
                      </span>
                    )}
                    {o.pickupMinutes && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 font-semibold text-muted-foreground">
                        <Timer className="size-3" /> {o.pickupMinutes} {t("min")}
                      </span>
                    )}
                    {o.priceFrom && (
                      <span className="ms-auto font-bold text-primary">
                        {t("price_from")} {fmtCurrency(o.priceFrom)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-sm font-bold text-foreground">
              <Building2 className="size-4" /> {t("branches")} · {store.branches.length}
            </h3>
            <div className="space-y-1.5">
              {store.branches.map((b) => (
                <div key={b.id} className="flex items-center justify-between rounded-xl bg-muted/50 px-3 py-2 text-sm">
                  <div>
                    <div className="font-semibold">{b.district[lang]}</div>
                    <div className="text-xs text-muted-foreground">{b.address[lang]}</div>
                  </div>
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${b.lat},${b.lng}`}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full bg-primary/10 p-2 text-primary hover:bg-primary/15"
                  >
                    <Navigation className="size-4" />
                  </a>
                </div>
              ))}
            </div>
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}
