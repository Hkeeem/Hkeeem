import { Star, Zap, Timer, BadgePercent } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import type { Store, Branch } from "@/lib/mock-data";
import { StoreDetails } from "./StoreDetails";
import { useState } from "react";

export function StoreCard({
  store,
  branch,
  distanceKm,
  compact,
}: {
  store: Store;
  branch: Branch;
  distanceKm: number;
  compact?: boolean;
}) {
  const { t, lang, fmtDistance, fmtCurrency } = useI18n();
  const [open, setOpen] = useState(false);
  const bestOffer = store.offers[0];

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className={`group relative w-full overflow-hidden rounded-3xl bg-card text-start shadow-[var(--shadow-soft)] transition-all hover:-translate-y-0.5 hover:shadow-lg ${
          compact ? "" : "border border-border/60"
        }`}
      >
        <div className="flex items-stretch gap-3 p-3">
          <div
            className="grid size-16 shrink-0 place-items-center rounded-2xl text-3xl"
            style={{ background: `color-mix(in oklch, ${store.brandColor} 15%, white)` }}
          >
            {store.logo}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="truncate text-sm font-bold text-foreground">
                  {store.name[lang]}
                </div>
                <div className="mt-0.5 truncate text-xs text-muted-foreground">
                  {branch.district[lang]} · {fmtDistance(distanceKm)}
                </div>
              </div>
              <div className="flex items-center gap-0.5 rounded-full bg-accent/60 px-2 py-0.5 text-xs font-semibold text-accent-foreground">
                <Star className="size-3 fill-current" />
                {store.rating.toFixed(1)}
              </div>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <span className="gold-chip inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px]">
                <BadgePercent className="size-3" />
                {store.cashbackPct}% {t("cashback")}
              </span>
              {bestOffer?.discountPct && (
                <span className="inline-flex items-center gap-1 rounded-full bg-destructive/10 px-2 py-0.5 text-[11px] font-semibold text-destructive">
                  -{bestOffer.discountPct}%
                </span>
              )}
              {bestOffer?.flash && (
                <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-semibold text-primary">
                  <Zap className="size-3" /> Flash
                </span>
              )}
              {bestOffer?.pickupMinutes && (
                <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
                  <Timer className="size-3" /> {bestOffer.pickupMinutes} {t("min")}
                </span>
              )}
            </div>

            {bestOffer && (
              <div className="mt-1.5 truncate text-xs text-foreground/80">
                {bestOffer.title[lang]}
                {bestOffer.priceFrom ? (
                  <span className="ms-1 font-semibold text-primary">
                    {t("price_from")} {fmtCurrency(bestOffer.priceFrom)}
                  </span>
                ) : null}
              </div>
            )}
          </div>
        </div>
      </button>
      <StoreDetails store={store} branch={branch} distanceKm={distanceKm} open={open} onOpenChange={setOpen} />
    </>
  );
}
