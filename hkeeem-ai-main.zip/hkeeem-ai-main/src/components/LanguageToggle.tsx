import { Languages } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";

export function LanguageToggle() {
  const { lang, setLang, t } = useI18n();
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => setLang(lang === "ar" ? "en" : "ar")}
      className="gap-1.5 rounded-full border-primary/20 bg-card font-semibold text-primary hover:bg-primary/5"
    >
      <Languages className="size-4" />
      {t("switch_lang")}
    </Button>
  );
}
