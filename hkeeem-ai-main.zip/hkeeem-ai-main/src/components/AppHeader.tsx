import { Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";
import { LanguageToggle } from "./LanguageToggle";

export function AppHeader() {
  const { t } = useI18n();

  return (
    <header className="sticky top-0 z-50 border-b border-[#D4AF37]/20 bg-[#111111]/95 backdrop-blur-xl">
      <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">

        <Link to="/" className="flex items-center gap-3">

          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#D4AF37] shadow-lg">
            <span className="text-2xl font-black text-[#111111]">
              ح
            </span>
          </div>

          <div>
            <h1 className="text-lg font-extrabold text-white">
              Hkeeem <span className="text-[#D4AF37]">AI</span>
            </h1>

            <p className="text-xs text-[#F8F5EE]/80">
              منصة الذكاء الاقتصادي
            </p>
          </div>

        </Link>

        <LanguageToggle />

      </div>
    </header>
  );
}
