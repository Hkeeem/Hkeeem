import { Link, useRouterState } from "@tanstack/react-router";
import { Home, MapPin, Sparkles, Compass } from "lucide-react";
import { useI18n } from "@/lib/i18n";

const items = [
  { to: "/", icon: Home, key: "nav_home" as const },
  { to: "/nearby", icon: Compass, key: "nav_nearby" as const },
  { to: "/map", icon: MapPin, key: "nav_map" as const },
  { to: "/ai", icon: Sparkles, key: "nav_ai" as const },
];

export function BottomNav() {
  const { t } = useI18n();
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border/60 bg-background/85 backdrop-blur-lg">
      <div className="mx-auto grid max-w-md grid-cols-4">
        {items.map(({ to, icon: Icon, key }) => {
          const active = to === "/" ? path === "/" : path.startsWith(to);
          return (
            <Link
              key={to}
              to={to}
              className={`flex flex-col items-center gap-1 py-2.5 text-xs font-medium transition-colors ${
                active ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <span
                className={`grid size-9 place-items-center rounded-full transition-all ${
                  active ? "bg-primary text-primary-foreground shadow-[var(--shadow-soft)]" : ""
                }`}
              >
                <Icon className="size-4" />
              </span>
              {t(key)}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
