import { useEffect, useMemo, useRef, useState } from "react";
import { APIProvider, Map, Marker, useMap, InfoWindow } from "@vis.gl/react-google-maps";
import { MarkerClusterer, type Marker as ClusterMarker } from "@googlemaps/markerclusterer";
import { allBranches, RIYADH_CENTER, type Store, type Branch } from "@/lib/mock-data";
import { haversineKm } from "@/lib/geo";
import { useI18n } from "@/lib/i18n";
import type { Coords } from "@/lib/use-location";
import { StoreDetails } from "./StoreDetails";

const BROWSER_KEY = import.meta.env.VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_BROWSER_KEY as string | undefined;

type Item = { store: Store; branch: Branch };

function pinIcon(color: string) {
  const svg = `<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg" width="40" height="52" viewBox="0 0 40 52"><defs><filter id="s" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="2" stdDeviation="1.5" flood-opacity="0.35"/></filter></defs><path filter="url(#s)" fill="${color}" stroke="white" stroke-width="2.5" d="M20 2C11 2 4 9 4 18c0 12 16 32 16 32s16-20 16-32C36 9 29 2 20 2z"/><circle cx="20" cy="18" r="6.5" fill="white"/></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function ClusteredMarkers({ items, onPick }: { items: Item[]; onPick: (i: Item) => void }) {
  const map = useMap();
  const markersRef = useRef<Record<string, ClusterMarker>>({});
  const clustererRef = useRef<MarkerClusterer | null>(null);

  useEffect(() => {
    if (!map) return;
    const c = new MarkerClusterer({ map });
    clustererRef.current = c;
    c.addMarkers(Object.values(markersRef.current));
    return () => {
      c.clearMarkers();
      clustererRef.current = null;
    };
  }, [map]);

  const setRef = (id: string) => (m: ClusterMarker | null) => {
    const c = clustererRef.current;
    const prev = markersRef.current[id];
    if (m) {
      if (prev === m) return;
      if (prev && c) c.removeMarker(prev);
      markersRef.current[id] = m;
      if (c) c.addMarker(m);
    } else if (prev) {
      if (c) c.removeMarker(prev);
      delete markersRef.current[id];
    }
  };

  return (
    <>
      {items.map((it) => (
        <Marker
          key={it.branch.id}
          position={{ lat: it.branch.lat, lng: it.branch.lng }}
          ref={setRef(it.branch.id)}
          onClick={() => onPick(it)}
          icon={{ url: pinIcon(it.store.brandColor), scaledSize: { width: 36, height: 46 }, anchor: { x: 18, y: 46 } }}
          title={it.store.name.en}
        />
      ))}
    </>
  );
}

function userPinIcon() {
  const svg = `<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30"><circle cx="15" cy="15" r="10" fill="#e0b34a" stroke="white" stroke-width="4"/><circle cx="15" cy="15" r="14" fill="none" stroke="#e0b34a" stroke-width="2" opacity="0.4"/></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function MapView({ userCoords, filterStoreIds }: { userCoords: Coords; filterStoreIds?: string[] }) {
  const { t, lang, fmtDistance } = useI18n();
  const [picked, setPicked] = useState<Item | null>(null);
  const [sheet, setSheet] = useState(false);

  const items = useMemo(() => {
    const all = allBranches();
    if (!filterStoreIds || filterStoreIds.length === 0) return all;
    const set = new Set(filterStoreIds);
    return all.filter((it) => set.has(it.store.id));
  }, [filterStoreIds]);

  if (!BROWSER_KEY) {
    return (
      <div className="grid h-full place-items-center bg-muted p-6 text-center text-sm text-muted-foreground">
        Google Maps browser key is not configured.
      </div>
    );
  }

  const distance = picked ? haversineKm(userCoords, { lat: picked.branch.lat, lng: picked.branch.lng }) : 0;

  return (
    <div className="relative h-full w-full">
      <APIProvider apiKey={BROWSER_KEY}>
        <Map
          defaultCenter={userCoords ?? RIYADH_CENTER}
          defaultZoom={12}
          gestureHandling="greedy"
          disableDefaultUI={false}
          className="h-full w-full"
        >
          <Marker
            position={userCoords}
            icon={{ url: userPinIcon(), scaledSize: { width: 30, height: 30 }, anchor: { x: 15, y: 15 } }}
            title={t("you_are_here")}
          />
          <ClusteredMarkers items={items} onPick={(it) => setPicked(it)} />
          {picked && (
            <InfoWindow
              position={{ lat: picked.branch.lat, lng: picked.branch.lng }}
              onCloseClick={() => setPicked(null)}
              pixelOffset={[0, -40]}
            >
              <div className="min-w-40 space-y-1 p-1 text-start" dir={lang === "ar" ? "rtl" : "ltr"}>
                <div className="text-sm font-bold text-foreground">{picked.store.name[lang]}</div>
                <div className="text-xs text-muted-foreground">
                  {picked.branch.district[lang]} · {fmtDistance(distance)}
                </div>
                <div className="text-xs font-semibold" style={{ color: picked.store.brandColor }}>
                  {picked.store.cashbackPct}% {t("cashback")}
                </div>
                <button
                  onClick={() => setSheet(true)}
                  className="mt-1 w-full rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground"
                >
                  {t("view_on_map")}
                </button>
              </div>
            </InfoWindow>
          )}
        </Map>
      </APIProvider>
      {picked && (
        <StoreDetails
          store={picked.store}
          branch={picked.branch}
          distanceKm={distance}
          open={sheet}
          onOpenChange={setSheet}
        />
      )}
    </div>
  );
}
