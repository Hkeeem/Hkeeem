import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "ar" | "en";

type Dict = Record<string, { ar: string; en: string }>;

export const STRINGS: Dict = {
  app_name: { ar: "حكيم", en: "Hkeeem" },
  app_tagline: { ar: "أذكى طريقة لتوفر مالك", en: "The smartest way to save" },
  nav_home: { ar: "الرئيسية", en: "Home" },
  nav_nearby: { ar: "بالقرب", en: "Nearby" },
  nav_map: { ar: "الخريطة", en: "Map" },
  nav_ai: { ar: "الذكاء", en: "AI" },
  search_placeholder: { ar: "ابحث عن متجر، مدينة، أو حي", en: "Search store, city, or district" },
  use_my_location: { ar: "استخدم موقعي الحالي", en: "Use my current location" },
  requesting_location: { ar: "جارٍ تحديد الموقع…", en: "Getting your location…" },
  location_denied: { ar: "تعذر الوصول للموقع. تم استخدام الرياض كموقع افتراضي.", en: "Location unavailable. Using Riyadh as default." },
  nearby_deals: { ar: "عروض قريبة منك", en: "Deals near you" },
  see_all: { ar: "عرض الكل", en: "See all" },
  distance_km: { ar: "كم", en: "km" },
  distance_m: { ar: "م", en: "m" },
  cashback: { ar: "كاش باك", en: "Cashback" },
  discount: { ar: "خصم", en: "Discount" },
  open_now: { ar: "مفتوح الآن", en: "Open now" },
  closed: { ar: "مغلق", en: "Closed" },
  navigate: { ar: "التوجه إلى المتجر", en: "Get directions" },
  google_maps: { ar: "خرائط جوجل", en: "Google Maps" },
  apple_maps: { ar: "خرائط آبل", en: "Apple Maps" },
  branches: { ar: "الفروع", en: "Branches" },
  offers: { ar: "العروض", en: "Offers" },
  hours: { ar: "أوقات العمل", en: "Opening hours" },
  rating: { ar: "التقييم", en: "Rating" },
  ai_title: { ar: "مساعد حكيم الذكي", en: "Hkeeem AI Assistant" },
  ai_subtitle: { ar: "احصل على أفضل توصية بناءً على السعر، الكاش باك، والمسافة", en: "Best pick by price, cashback and distance" },
  ai_ask: { ar: "ما الذي تبحث عنه اليوم؟", en: "What are you looking for today?" },
  ai_examples: { ar: "أمثلة: أرخص برجر قريب، أفضل صيدلية بكاش باك، أسرع استلام قهوة", en: "Try: cheapest burger nearby, best pharmacy cashback, fastest coffee pickup" },
  ai_thinking: { ar: "حكيم يفكر…", en: "Hkeeem is thinking…" },
  ai_best_pick: { ar: "أفضل اختيار", en: "Best pick" },
  ai_reason: { ar: "السبب", en: "Why" },
  ai_alternatives: { ar: "بدائل قريبة", en: "Nearby alternatives" },
  filter_all: { ar: "الكل", en: "All" },
  sort_nearest: { ar: "الأقرب", en: "Nearest" },
  new_offers: { ar: "عروض جديدة قريبة", en: "New nearby offers" },
  flash_deals: { ar: "عروض سريعة قريبة", en: "Flash deals nearby" },
  today_discounts: { ar: "خصومات اليوم القريبة", en: "Today's nearby discounts" },
  stores_near_me: { ar: "متاجر قريبة مني", en: "Stores near me" },
  deals_near_me: { ar: "عروض قريبة مني", en: "Deals near me" },
  live_updates: { ar: "تحديث مباشر", en: "Live updates" },
  km_away: { ar: "بعيد عنك", en: "away" },
  view_on_map: { ar: "عرض على الخريطة", en: "View on map" },
  cat_restaurants: { ar: "مطاعم", en: "Restaurants" },
  cat_pharmacies: { ar: "صيدليات", en: "Pharmacies" },
  cat_supermarkets: { ar: "سوبرماركت", en: "Supermarkets" },
  cat_electronics: { ar: "إلكترونيات", en: "Electronics" },
  cat_fashion: { ar: "أزياء", en: "Fashion" },
  cat_realestate: { ar: "عقارات", en: "Real estate" },
  cat_coffee: { ar: "قهوة", en: "Coffee" },
  cat_beauty: { ar: "تجميل", en: "Beauty" },
  no_results: { ar: "لا توجد نتائج", en: "No results" },
  loading_map: { ar: "جارٍ تحميل الخريطة…", en: "Loading map…" },
  you_are_here: { ar: "موقعك", en: "You are here" },
  offers_count: { ar: "عرض", en: "offers" },
  min_pickup: { ar: "استلام خلال", en: "Pickup in" },
  min: { ar: "د", en: "min" },
  price_from: { ar: "يبدأ من", en: "From" },
  currency: { ar: "ر.س", en: "SAR" },
  switch_lang: { ar: "English", en: "العربية" },
  realestate_title: { ar: "العقارات — مكتبي الافتراضي", en: "Real Estate — My Virtual Office" },
  realestate_org: { ar: "مؤسسة محسن لخدمات الأعمال", en: "Mohsen Business Services" },
  realestate_desc: {
    ar: "يسعدني استقبال طلباتكم وعروضكم عبر رابط مكتبي العقاري، وسنقوم بخدمتكم في أقرب فرصة.",
    en: "Send me your requests and offers via my virtual real estate office and I'll serve you as soon as possible.",
  },
  realestate_cta: { ar: "زيارة مكتبي العقاري على DealApp", en: "Visit my real estate office on DealApp" },
  realestate_cta_hint: { ar: "يفتح في تبويب جديد", en: "Opens in a new tab" },
};

const I18nCtx = createContext<{
  lang: Lang;
  dir: "rtl" | "ltr";
  t: (key: keyof typeof STRINGS) => string;
  setLang: (l: Lang) => void;
  fmtNumber: (n: number) => string;
  fmtCurrency: (n: number) => string;
  fmtDistance: (km: number) => string;
} | null>(null);

const NUM_LOCALE: Record<Lang, string> = { ar: "ar-SA", en: "en-US" };

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");

  useEffect(() => {
    const stored = typeof window !== "undefined" ? (window.localStorage.getItem("hkeeem_lang") as Lang | null) : null;
    if (stored === "ar" || stored === "en") setLangState(stored);
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = (l: Lang) => {
    setLangState(l);
    try { window.localStorage.setItem("hkeeem_lang", l); } catch {}
  };

  const value = {
    lang,
    dir: (lang === "ar" ? "rtl" : "ltr") as "rtl" | "ltr",
    t: (k: keyof typeof STRINGS) => STRINGS[k]?.[lang] ?? String(k),
    setLang,
    fmtNumber: (n: number) => new Intl.NumberFormat(NUM_LOCALE[lang]).format(n),
    fmtCurrency: (n: number) =>
      new Intl.NumberFormat(NUM_LOCALE[lang], { style: "currency", currency: "SAR", maximumFractionDigits: 0 }).format(n),
    fmtDistance: (km: number) => {
      if (km < 1) return `${new Intl.NumberFormat(NUM_LOCALE[lang]).format(Math.round(km * 1000))} ${STRINGS.distance_m[lang]}`;
      return `${new Intl.NumberFormat(NUM_LOCALE[lang], { maximumFractionDigits: 1 }).format(km)} ${STRINGS.distance_km[lang]}`;
    },
  };

  return <I18nCtx.Provider value={value}>{children}</I18nCtx.Provider>;
}

export function useI18n() {
  const c = useContext(I18nCtx);
  if (!c) throw new Error("useI18n must be used inside I18nProvider");
  return c;
}

export function tr(s: { ar: string; en: string }, lang: Lang) {
  return s[lang];
}
