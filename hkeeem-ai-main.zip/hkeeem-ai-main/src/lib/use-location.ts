import { useEffect, useState } from "react";
import { RIYADH_CENTER } from "./mock-data";

export type Coords = { lat: number; lng: number };

export function useLiveLocation(watch = true) {
  const [coords, setCoords] = useState<Coords>(RIYADH_CENTER);
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "denied">("idle");

  useEffect(() => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      setStatus("denied");
      return;
    }
    setStatus("loading");
    const onOk = (pos: GeolocationPosition) => {
      setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      setStatus("ok");
    };
    const onErr = () => setStatus("denied");
    if (watch) {
      const id = navigator.geolocation.watchPosition(onOk, onErr, {
        enableHighAccuracy: false,
        maximumAge: 15000,
        timeout: 12000,
      });
      return () => navigator.geolocation.clearWatch(id);
    }
    navigator.geolocation.getCurrentPosition(onOk, onErr, { timeout: 10000 });
  }, [watch]);

  return { coords, status };
}
