// Lightweight client-side analytics dispatcher.
// Pushes events to window.dataLayer (GA4/GTM compatible), emits a CustomEvent
// on window, mirrors to console in dev, and keeps a rolling log in
// localStorage so we can inspect clicks without a full analytics backend.

export type AnalyticsEvent = {
  event: string;
  [key: string]: unknown;
};

const STORAGE_KEY = "hkeeem:analytics:log";
const MAX_LOG = 100;

declare global {
  interface Window {
    dataLayer?: Array<Record<string, unknown>>;
  }
}

export function trackEvent(event: string, params: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;

  const payload: AnalyticsEvent = {
    event,
    ts: new Date().toISOString(),
    path: window.location.pathname + window.location.search,
    referrer: document.referrer || null,
    ...params,
  };

  try {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push(payload);
  } catch {
    /* ignore */
  }

  try {
    window.dispatchEvent(new CustomEvent("hkeeem:analytics", { detail: payload }));
  } catch {
    /* ignore */
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const list: AnalyticsEvent[] = raw ? JSON.parse(raw) : [];
    list.push(payload);
    if (list.length > MAX_LOG) list.splice(0, list.length - MAX_LOG);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    /* ignore quota / private mode */
  }

  if (import.meta.env.DEV) {
    // eslint-disable-next-line no-console
    console.debug("[analytics]", event, payload);
  }
}

export function getAnalyticsLog(): AnalyticsEvent[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}
