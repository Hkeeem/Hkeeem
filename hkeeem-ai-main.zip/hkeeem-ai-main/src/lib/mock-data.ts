export type Bilingual = { ar: string; en: string };

export type Category =
  | "restaurants"
  | "pharmacies"
  | "supermarkets"
  | "electronics"
  | "fashion"
  | "realestate"
  | "coffee"
  | "beauty";

export const CATEGORY_META: Record<Category, { icon: string; label: Bilingual; color: string }> = {
  restaurants: { icon: "🍔", label: { ar: "مطاعم", en: "Restaurants" }, color: "oklch(0.75 0.16 40)" },
  pharmacies: { icon: "💊", label: { ar: "صيدليات", en: "Pharmacies" }, color: "oklch(0.65 0.15 150)" },
  supermarkets: { icon: "🛒", label: { ar: "سوبرماركت", en: "Supermarkets" }, color: "oklch(0.65 0.15 260)" },
  electronics: { icon: "📱", label: { ar: "إلكترونيات", en: "Electronics" }, color: "oklch(0.5 0.15 280)" },
  fashion: { icon: "👗", label: { ar: "أزياء", en: "Fashion" }, color: "oklch(0.65 0.2 340)" },
  realestate: { icon: "🏢", label: { ar: "عقارات", en: "Real estate" }, color: "oklch(0.5 0.1 220)" },
  coffee: { icon: "☕", label: { ar: "قهوة", en: "Coffee" }, color: "oklch(0.45 0.08 40)" },
  beauty: { icon: "💄", label: { ar: "تجميل", en: "Beauty" }, color: "oklch(0.7 0.18 0)" },
};

export type Offer = {
  id: string;
  title: Bilingual;
  discountPct?: number;
  cashbackPct?: number;
  priceFrom?: number;
  flash?: boolean;
  newlyAdded?: boolean;
  todayOnly?: boolean;
  pickupMinutes?: number;
};

export type Branch = {
  id: string;
  name: Bilingual;
  lat: number;
  lng: number;
  address: Bilingual;
  district: Bilingual;
};

export type Store = {
  id: string;
  name: Bilingual;
  category: Category;
  logo: string; // emoji-based logo
  brandColor: string;
  rating: number;
  reviews: number;
  city: Bilingual;
  hours: Bilingual;
  openNow: boolean;
  cashbackPct: number;
  branches: Branch[];
  offers: Offer[];
};

// Center on Riyadh
const R = { lat: 24.7136, lng: 46.6753 };

// Deterministic PRNG so SSR and client produce identical branch coords.
let _seed = 1337;
function rand() {
  _seed = (_seed * 9301 + 49297) % 233280;
  return _seed / 233280;
}
function jitter(base: number, spread: number) {
  return base + (rand() - 0.5) * spread;
}

let branchCounter = 0;
function mkBranches(count: number, name: Bilingual, districts: Bilingual[]): Branch[] {
  return Array.from({ length: count }).map(() => {
    const d = districts[Math.floor(rand() * districts.length)];
    branchCounter += 1;
    return {
      id: `b-${branchCounter}`,
      name,
      lat: jitter(R.lat, 0.15),
      lng: jitter(R.lng, 0.2),
      district: d,
      address: {
        ar: `شارع الأمير محمد، ${d.ar}`,
        en: `Prince Mohammed St, ${d.en}`,
      },
    };
  });
}

const DISTRICTS: Bilingual[] = [
  { ar: "العليا", en: "Al Olaya" },
  { ar: "الملز", en: "Al Malaz" },
  { ar: "النخيل", en: "Al Nakheel" },
  { ar: "الياسمين", en: "Al Yasmin" },
  { ar: "حطين", en: "Hittin" },
  { ar: "الروضة", en: "Al Rawdah" },
  { ar: "السليمانية", en: "Al Sulaymaniyah" },
  { ar: "الملقا", en: "Al Malqa" },
  { ar: "الورود", en: "Al Wurud" },
  { ar: "قرطبة", en: "Qurtubah" },
];

const RIYADH: Bilingual = { ar: "الرياض", en: "Riyadh" };

export const STORES: Store[] = [
  {
    id: "s-albaik",
    name: { ar: "البيك", en: "AlBaik" },
    category: "restaurants",
    logo: "🍗",
    brandColor: "oklch(0.55 0.2 30)",
    rating: 4.8, reviews: 12430,
    city: RIYADH,
    hours: { ar: "١٠:٠٠ ص – ٢:٠٠ ص", en: "10:00 AM – 2:00 AM" },
    openNow: true, cashbackPct: 8,
    branches: mkBranches(4, { ar: "البيك", en: "AlBaik" }, DISTRICTS),
    offers: [
      { id: "o1", title: { ar: "وجبة برودست + مشروب", en: "Broasted meal + drink" }, discountPct: 20, cashbackPct: 8, priceFrom: 24, flash: true, pickupMinutes: 12 },
      { id: "o2", title: { ar: "٤ قطع للعائلة", en: "4-piece family bucket" }, discountPct: 15, cashbackPct: 8, priceFrom: 55, todayOnly: true },
    ],
  },
  {
    id: "s-herfy",
    name: { ar: "هرفي", en: "Herfy" },
    category: "restaurants",
    logo: "🍔",
    brandColor: "oklch(0.55 0.22 25)",
    rating: 4.4, reviews: 8210,
    city: RIYADH,
    hours: { ar: "٢٤ ساعة", en: "24 hours" },
    openNow: true, cashbackPct: 6,
    branches: mkBranches(3, { ar: "هرفي", en: "Herfy" }, DISTRICTS),
    offers: [
      { id: "o3", title: { ar: "برجر مشوي + بطاطس", en: "Grilled burger + fries" }, discountPct: 25, cashbackPct: 6, priceFrom: 19, flash: true, pickupMinutes: 8, newlyAdded: true },
    ],
  },
  {
    id: "s-starbucks",
    name: { ar: "ستاربكس", en: "Starbucks" },
    category: "coffee",
    logo: "☕",
    brandColor: "oklch(0.4 0.1 150)",
    rating: 4.5, reviews: 5410,
    city: RIYADH,
    hours: { ar: "٦:٠٠ ص – ١٢:٠٠ م", en: "6:00 AM – 12:00 AM" },
    openNow: true, cashbackPct: 10,
    branches: mkBranches(5, { ar: "ستاربكس", en: "Starbucks" }, DISTRICTS),
    offers: [
      { id: "o4", title: { ar: "لاتيه كبير + كرواسون", en: "Grande latte + croissant" }, discountPct: 15, cashbackPct: 10, priceFrom: 28, pickupMinutes: 6 },
      { id: "o5", title: { ar: "عرض الشتاء – فرابتشينو", en: "Winter Frappuccino" }, cashbackPct: 12, priceFrom: 22, newlyAdded: true },
    ],
  },
  {
    id: "s-nahdi",
    name: { ar: "صيدلية النهدي", en: "Al Nahdi Pharmacy" },
    category: "pharmacies",
    logo: "💊",
    brandColor: "oklch(0.55 0.18 150)",
    rating: 4.6, reviews: 9820,
    city: RIYADH,
    hours: { ar: "٧:٠٠ ص – ١:٠٠ ص", en: "7:00 AM – 1:00 AM" },
    openNow: true, cashbackPct: 5,
    branches: mkBranches(6, { ar: "النهدي", en: "Al Nahdi" }, DISTRICTS),
    offers: [
      { id: "o6", title: { ar: "خصم على الفيتامينات", en: "Vitamins discount" }, discountPct: 30, cashbackPct: 5, priceFrom: 45, todayOnly: true },
      { id: "o7", title: { ar: "منتجات العناية", en: "Personal care" }, discountPct: 20, cashbackPct: 5 },
    ],
  },
  {
    id: "s-dawaa",
    name: { ar: "صيدلية الدواء", en: "Al Dawaa Pharmacy" },
    category: "pharmacies",
    logo: "🧴",
    brandColor: "oklch(0.5 0.16 160)",
    rating: 4.4, reviews: 5320,
    city: RIYADH,
    hours: { ar: "٨:٠٠ ص – ١٢:٠٠ م", en: "8:00 AM – 12:00 AM" },
    openNow: true, cashbackPct: 7,
    branches: mkBranches(4, { ar: "الدواء", en: "Al Dawaa" }, DISTRICTS),
    offers: [
      { id: "o8", title: { ar: "الفيتامينات بسعر مخفض", en: "Vitamins offer" }, discountPct: 25, cashbackPct: 7, priceFrom: 39, flash: true, pickupMinutes: 10 },
    ],
  },
  {
    id: "s-danube",
    name: { ar: "الدانوب", en: "Danube" },
    category: "supermarkets",
    logo: "🛒",
    brandColor: "oklch(0.5 0.18 240)",
    rating: 4.6, reviews: 7810,
    city: RIYADH,
    hours: { ar: "٨:٠٠ ص – ١٢:٠٠ م", en: "8:00 AM – 12:00 AM" },
    openNow: true, cashbackPct: 4,
    branches: mkBranches(3, { ar: "الدانوب", en: "Danube" }, DISTRICTS),
    offers: [
      { id: "o9", title: { ar: "عروض الأسبوع الطازجة", en: "Weekly fresh deals" }, discountPct: 35, cashbackPct: 4, priceFrom: 15, todayOnly: true },
    ],
  },
  {
    id: "s-carrefour",
    name: { ar: "كارفور", en: "Carrefour" },
    category: "supermarkets",
    logo: "🥬",
    brandColor: "oklch(0.55 0.2 245)",
    rating: 4.3, reviews: 12210,
    city: RIYADH,
    hours: { ar: "٩:٠٠ ص – ١٢:٠٠ م", en: "9:00 AM – 12:00 AM" },
    openNow: true, cashbackPct: 6,
    branches: mkBranches(5, { ar: "كارفور", en: "Carrefour" }, DISTRICTS),
    offers: [
      { id: "o10", title: { ar: "٢ بسعر ١ – منتجات مختارة", en: "2 for 1 selected items" }, discountPct: 50, cashbackPct: 6, priceFrom: 20, flash: true, pickupMinutes: 20 },
    ],
  },
  {
    id: "s-jarir",
    name: { ar: "جرير", en: "Jarir Bookstore" },
    category: "electronics",
    logo: "📱",
    brandColor: "oklch(0.5 0.15 280)",
    rating: 4.7, reviews: 15300,
    city: RIYADH,
    hours: { ar: "٩:٠٠ ص – ١١:٠٠ م", en: "9:00 AM – 11:00 PM" },
    openNow: true, cashbackPct: 3,
    branches: mkBranches(3, { ar: "جرير", en: "Jarir" }, DISTRICTS),
    offers: [
      { id: "o11", title: { ar: "خصم على الإكسسوارات", en: "Accessories discount" }, discountPct: 20, cashbackPct: 3, priceFrom: 79, newlyAdded: true },
      { id: "o12", title: { ar: "لابتوبات مختارة", en: "Selected laptops" }, cashbackPct: 5, priceFrom: 2499 },
    ],
  },
  {
    id: "s-extra",
    name: { ar: "إكسترا", en: "eXtra" },
    category: "electronics",
    logo: "🎮",
    brandColor: "oklch(0.55 0.22 30)",
    rating: 4.5, reviews: 9430,
    city: RIYADH,
    hours: { ar: "١٠:٠٠ ص – ١١:٠٠ م", en: "10:00 AM – 11:00 PM" },
    openNow: true, cashbackPct: 4,
    branches: mkBranches(3, { ar: "إكسترا", en: "eXtra" }, DISTRICTS),
    offers: [
      { id: "o13", title: { ar: "تلفزيونات مخفضة", en: "TVs on sale" }, discountPct: 25, cashbackPct: 4, priceFrom: 1299, flash: true, pickupMinutes: 30 },
    ],
  },
  {
    id: "s-hm",
    name: { ar: "اتش اند ام", en: "H&M" },
    category: "fashion",
    logo: "👕",
    brandColor: "oklch(0.65 0.2 20)",
    rating: 4.2, reviews: 6300,
    city: RIYADH,
    hours: { ar: "١٠:٠٠ ص – ١٢:٠٠ م", en: "10:00 AM – 12:00 AM" },
    openNow: true, cashbackPct: 6,
    branches: mkBranches(3, { ar: "H&M", en: "H&M" }, DISTRICTS),
    offers: [
      { id: "o14", title: { ar: "أوفر التخفيضات على الشتاء", en: "Winter clearance" }, discountPct: 50, cashbackPct: 6, priceFrom: 29, todayOnly: true },
    ],
  },
  {
    id: "s-namshi",
    name: { ar: "نمشي", en: "Namshi" },
    category: "fashion",
    logo: "👗",
    brandColor: "oklch(0.6 0.2 340)",
    rating: 4.4, reviews: 4820,
    city: RIYADH,
    hours: { ar: "١٠:٠٠ ص – ١١:٠٠ م", en: "10:00 AM – 11:00 PM" },
    openNow: true, cashbackPct: 10,
    branches: mkBranches(2, { ar: "نمشي", en: "Namshi" }, DISTRICTS),
    offers: [
      { id: "o15", title: { ar: "أحذية رياضية بخصم", en: "Sneakers discount" }, discountPct: 30, cashbackPct: 10, priceFrom: 149, newlyAdded: true, flash: true, pickupMinutes: 45 },
    ],
  },
  {
    id: "s-alrajhi",
    name: { ar: "عقارات الراجحي", en: "Al Rajhi Properties" },
    category: "realestate",
    logo: "🏢",
    brandColor: "oklch(0.45 0.1 220)",
    rating: 4.5, reviews: 1230,
    city: RIYADH,
    hours: { ar: "٩:٠٠ ص – ٦:٠٠ م", en: "9:00 AM – 6:00 PM" },
    openNow: true, cashbackPct: 1,
    branches: mkBranches(2, { ar: "عقارات الراجحي", en: "Al Rajhi Properties" }, DISTRICTS),
    offers: [
      { id: "o16", title: { ar: "شقق فاخرة – خصم افتتاح", en: "Luxury apartments launch discount" }, discountPct: 8, priceFrom: 850000, newlyAdded: true },
    ],
  },
  {
    id: "s-sephora",
    name: { ar: "سيفورا", en: "Sephora" },
    category: "beauty",
    logo: "💄",
    brandColor: "oklch(0.6 0.22 0)",
    rating: 4.6, reviews: 3810,
    city: RIYADH,
    hours: { ar: "١٠:٠٠ ص – ١٢:٠٠ م", en: "10:00 AM – 12:00 AM" },
    openNow: true, cashbackPct: 8,
    branches: mkBranches(2, { ar: "سيفورا", en: "Sephora" }, DISTRICTS),
    offers: [
      { id: "o17", title: { ar: "عطور مختارة", en: "Selected fragrances" }, discountPct: 20, cashbackPct: 8, priceFrom: 199, flash: true, pickupMinutes: 25 },
    ],
  },
  {
    id: "s-dr-cafe",
    name: { ar: "دكتور كافيه", en: "Dr. Café" },
    category: "coffee",
    logo: "🫖",
    brandColor: "oklch(0.4 0.09 40)",
    rating: 4.5, reviews: 6120,
    city: RIYADH,
    hours: { ar: "٦:٠٠ ص – ١:٠٠ ص", en: "6:00 AM – 1:00 AM" },
    openNow: true, cashbackPct: 12,
    branches: mkBranches(4, { ar: "دكتور كافيه", en: "Dr. Café" }, DISTRICTS),
    offers: [
      { id: "o18", title: { ar: "اسبريسو مزدوج بنصف السعر", en: "Double espresso half price" }, discountPct: 50, cashbackPct: 12, priceFrom: 9, flash: true, pickupMinutes: 5, todayOnly: true },
    ],
  },
];

export const RIYADH_CENTER = R;

export type StoreWithBranch = {
  store: Store;
  branch: Branch;
  distanceKm: number;
};

export function allBranches(): { store: Store; branch: Branch }[] {
  return STORES.flatMap((s) => s.branches.map((b) => ({ store: s, branch: b })));
}
