import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { lovableChat } from "./ai-gateway.server";

const Input = z.object({
  query: z.string().min(1).max(300),
  lang: z.enum(["ar", "en"]),
  candidates: z
    .array(
      z.object({
        storeId: z.string(),
        storeName: z.string(),
        category: z.string(),
        distanceKm: z.number(),
        cashbackPct: z.number(),
        rating: z.number(),
        openNow: z.boolean(),
        bestOffer: z.object({
          title: z.string(),
          discountPct: z.number().optional(),
          priceFrom: z.number().optional(),
          pickupMinutes: z.number().optional(),
        }),
      }),
    )
    .min(1)
    .max(20),
});

export const recommendNearby = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => Input.parse(data))
  .handler(async ({ data }) => {
    const systemAr =
      "أنت مساعد ذكي اسمه (حكيم) لتطبيق عروض الكاش باك والخصومات في المملكة العربية السعودية. مهمتك اختيار أفضل متجر واحد من قائمة المرشحين بناءً على تحقيق أفضل توازن بين: قرب المسافة، أعلى كاش باك، أعلى خصم، أفضل تقييم، وسرعة الاستلام. أجب باللغة العربية فقط. أعد كائن JSON بالحقول: bestStoreId, reason, alternatives (مصفوفة من storeId مع سبب قصير لكل بديل، بحد أقصى 3).";
    const systemEn =
      "You are Hkeeem, an AI shopping assistant for a Saudi cashback and deals app. Pick the single best store from the candidates by balancing distance, cashback %, discount, rating, open-now, and pickup speed. Respond in English only. Return a JSON object with fields: bestStoreId, reason, alternatives (array of {storeId, reason}, max 3).";
    const res = await lovableChat({
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: data.lang === "ar" ? systemAr : systemEn },
        {
          role: "user",
          content:
            (data.lang === "ar" ? "طلب المستخدم: " : "User request: ") +
            data.query +
            "\n\n" +
            (data.lang === "ar" ? "المرشحون:\n" : "Candidates:\n") +
            JSON.stringify(data.candidates, null, 2),
        },
      ],
    });
    const raw = res.choices[0]?.message.content ?? "{}";
    let parsed: {
      bestStoreId?: string;
      reason?: string;
      alternatives?: Array<{ storeId: string; reason: string }>;
    } = {};
    try {
      parsed = JSON.parse(raw);
    } catch {
      // fall through — return empty shape
    }
    return {
      bestStoreId: parsed.bestStoreId ?? data.candidates[0].storeId,
      reason: parsed.reason ?? "",
      alternatives: (parsed.alternatives ?? []).slice(0, 3),
    };
  });
